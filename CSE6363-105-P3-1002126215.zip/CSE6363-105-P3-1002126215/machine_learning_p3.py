#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
bha=pd.read_csv("project3_train.csv",names=["b1","b2","b3","b4"])
bha2=pd.read_csv("project3_test.csv",names=["b1","b2","b3","b4"])


# In[2]:


import numpy as np
import matplotlib.pyplot as plt

d=bha.drop("b4",axis=1).values
l=bha["b4"].values
m, n = d.shape
lr= [0.001, 0.002, 0.006, 0.01, 0.1]

def lor(cx):
    lo=[]
    sa = np.zeros(n)
    for bx in range(5000):
        z = np.dot(d, sa)
        h =  1 / (1 + np.exp(-z))
        g = np.dot(d.T, (h - l)) / m
        sa= sa-(cx * g)
        el = (-l * np.log(h) - (1 - l) * np.log(1 - h))
        el=el.mean()
        lo.append(el)
    return lo

plt.figure(figsize=(9, 7))
for r in lr:
    loe= lor(r)
    plt.plot(range(5000), loe,label=f"rate={r}")


plt.xlabel('No of itera')
plt.ylabel('Loss')
plt.title('Loss vs. No of itera')
plt.legend()
plt.savefig('Loss vs. No of itera.png')
plt.show()


# In[4]:


import numpy as np
import matplotlib.pyplot as plt
import math
import time
import random

d=bha.drop("b4",axis=1).values
l=bha["b4"].values
d_T=bha2.drop("b4",axis=1).values
l_T=bha2["b4"].values
u,v= d.shape
o=l.shape

def lor(d,l,gradient_type):

    lo=[]
    sa = np.zeros(v)
    n=4
    if(gradient_type=="stochastic"):
      m=len(l)
      start_time = time.time()
      for bx in range(300000):
        for i in range(0,n):
          stgd = np.random.randint(0, m)
          z = np.dot(d[stgd], sa)
          h =  1 / (1 + np.exp(-z))
          g = np.dot(d[stgd].T, (h - l[stgd]))
          sa= sa- 0.1 * g

      end_time = time.time()
      tes = end_time - start_time

      pt = np.dot(d, sa)
      p =  1 / (1 + np.exp(-pt))
      trpr = (p>= 0.5).astype(int)
      tra= np.mean(trpr == l)
      pte = np.dot(d_T, sa)
      pe =  1 / (1 + np.exp(-pte))
      tpr = (pe>= 0.5).astype(int)
      ta = np.mean(tpr == l_T)
      return sa,tes,tra,ta

    if(gradient_type=="batch"):
        m=len(l)
        start_time = time.time()
        for bx in range(300000):
            z = np.dot(d, sa)
            h =  1 / (1 + np.exp(-z))
            g = np.dot(d.T, (h - l)) / m
            sa= sa- 0.1 * g
            el = -(1 / m) * np.sum(-l * np.log(h) - (1 - l) * np.log(1 - h))
            lo.append(el)

        end_time = time.time()
        tb = end_time - start_time

        pt = np.dot(d, sa)
        p =  1 / (1 + np.exp(-pt))
        trpr = (p>= 0.5).astype(int)
        tra= np.mean(trpr == l)
        pte = np.dot(d_T, sa)
        pe =  1 / (1 + np.exp(-pte))
        tpr = (pe>= 0.5).astype(int)
        ta = np.mean(tpr == l_T)
        return sa,tb,tra,ta

    if(gradient_type=="mini_batch"):
      start_time = time.time()
      for bx in range(300000):
          mb=random.sample(range(1,u),5)
          m=len(mb)
          z = np.dot(d[mb], sa)
          h =  1 / (1 + np.exp(-z))
          g = np.dot(d[mb].T, (h - l[mb])) / 5
          sa= sa- 0.1 * g
      end_time = time.time()
      tm= end_time - start_time

      pt = np.dot(d, sa)
      p =  1 / (1 + np.exp(-pt))
      trpr = (p>= 0.5).astype(int)
      tra= np.mean(trpr == l)
      pte = np.dot(d_T, sa)
      pe =  1 / (1 + np.exp(-pte))
      tpr = (pe>= 0.5).astype(int)
      ta = np.mean(tpr == l_T)
      return sa, tm,tra,ta

para, tim, tr_acc,te_acc=lor(d,l,"batch")
print("thetas or parameters of batch",para)
print("time for batch",tim)
print("accuracy for train in batch",tr_acc)
print("accuracy for test in batch",te_acc)
para_m, tim_m, tr_acc_m,te_acc_m=lor(d,l,"mini_batch")
print("thetas or parameters of mini batch",para_m)
print("time for mini batch",tim_m)
print("accuracy fot train in mini batch",tr_acc_m)
print("accuracy for test in mini batch",te_acc_m)
para_s, tim_s, tr_acc_s,te_acc_s=lor(d,l,"stochastic")
print("thetas or parameters of stochastic",para_s)
print("time for stochastic",tim_s)
print("accuracy fot train in stochastic",tr_acc_s)
print("accuracy for test in stochastic",te_acc_s)

