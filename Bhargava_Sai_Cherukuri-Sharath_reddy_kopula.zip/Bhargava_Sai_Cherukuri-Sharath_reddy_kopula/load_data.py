import pymysql
import csv


csv_files = {
    'members':'member.csv',
    'staff': 'staff.csv',
    'books': 'book.csv',
    'catalog': 'catalog - catalog.csv.csv',
    'borrows': 'borrows.csv',
    'membership': 'membership.csv'
}

# SQL insert statements for each table
insert_statements = {
    'members': "INSERT INTO members (ssn,name,home_address,campus_address,phone_no) VALUES (%s, %s, %s, %s, %s)",
    'staff': "INSERT INTO staff (ssn, name, position) VALUES (%s, %s, %s)",
    'books': "INSERT INTO books (isbn, title,language,copy_no,edition) VALUES (%s, %s, %s, %s, %s)",
    'catalog': "INSERT INTO catalog (isbn, title,author,description) VALUES (%s, %s, %s,%s)",
    'borrows': "INSERT INTO borrows (ssn, isbn, name, borrow_date,due_date, return_date) VALUES (%s, %s, %s, %s, %s,%s)",
    'membership': "INSERT INTO membership (ssn, name, card_no, expiry_date, type) VALUES (%s, %s, %s, %s, %s)"
}

# Function to load data from a CSV file and insert into the database
def load_data(table_name, csv_path, insert_sql):
    connection = pymysql.connect(host='localhost', user='root', password='Cherukuri01@', database='library')
    try:
        with connection.cursor() as cursor:
            with open(csv_path, newline='', encoding='utf-8') as csvfile:
                reader = csv.reader(csvfile)
                for row in reader:
                    cursor.execute(insert_sql, row)
        connection.commit()
    finally:
        connection.close()

# Execute the data loading for each table
for table, path in csv_files.items():
    load_data(table, path, insert_statements[table])
    print(f"Data loaded into {table} from {path}")