select state from State order by land_area desc limit 1;

SELECT c.county, c.state, c.pop, conc.testDate, conc.positive_count, (conc.positive_count / c.pop * 1000) AS  po FROM County c JOIN Confirmed_cases conc ON c.county = conc.county AND c.state = conc.state where positive_count>0 ORDER BY po desc;
SELECT c.county, c.state, c.pop, de.report_date, de.death_count, (de.death_count / c.pop * 1000) AS denspopulation FROM County c JOIN Deaths de ON c.county = de.county AND c.state = de.state where death_count>=1 ORDER BY denspopulation DESC;

SELECT State, County, positive_count FROM (select *,ROW_NUMBER() OVER (PARTITION BY State ORDER BY positive_count DESC) as countyr from Confirmed_cases) as rankc where countyr<=10;

SELECT State, County, death_count FROM (select *,ROW_NUMBER() OVER (PARTITION BY State ORDER BY death_count DESC) AS Cr FROM Deaths) AS Ranked WHERE Cr <= 10;

insert into State values (21,'Alaska','AL',189,'Mont',186,5.40,0,764,336);
insert into State values (66,Null,'AL',18,'Momery',18,1.40,0,25,37);
insert into County values('india','srin',24527,34.378,-82.461707);

delete from County where state='maimi';

insert into State values (85,'sri','sl',1,'rav',18,10.01,1,764,536);
insert into State values (90,'pak','pk',67,'ter',1543,101.01,0,768,899);
insert into State values (65,'mal','md',25,'vac',15,1.01,0,68,99);
delete from State where state=sri;
select * from State;